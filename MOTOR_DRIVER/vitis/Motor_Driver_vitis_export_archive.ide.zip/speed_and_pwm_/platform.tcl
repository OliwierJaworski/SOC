# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct C:\School\Academiejaar_2024-25\systemOnChip\motorDriver\speed_and_pwm_\platform.tcl
# 
# OR launch xsct and run below command.
# source C:\School\Academiejaar_2024-25\systemOnChip\motorDriver\speed_and_pwm_\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {speed_and_pwm_}\
-hw {C:\School\Academiejaar_2024-25\systemOnChip\motorDriver\speed_and_pwm_.xsa}\
-out {C:/School/Academiejaar_2024-25/systemOnChip/motorDriver}

platform write
domain create -name {standalone_ps7_cortexa9_0} -display-name {standalone_ps7_cortexa9_0} -os {standalone} -proc {ps7_cortexa9_0} -runtime {cpp} -arch {32-bit} -support-app {hello_world}
platform generate -domains 
platform active {speed_and_pwm_}
domain active {zynq_fsbl}
domain active {standalone_ps7_cortexa9_0}
platform generate -quick
platform clean
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
