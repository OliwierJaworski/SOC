#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "SOC_MOTOR_DRIVER.h"
#include "xil_io.h"
#include "xparameters.h"

#define motor_baseaddr XPAR_SOC_MOTOR_DRIVER_0_S00_AXI_BASEADDR
#define speedsens_baseaddr XPAR_SPEEDSENSOR_IP_1_0_0_S00_AXI_BASEADDR

int main() {
    init_platform();

    print("Motor Control Program Started\n\r");

    uint32_t pwm_period = 0;
    uint32_t pwm_frequency = 0;
    uint32_t mux_select = 0;

    while (1) {
        printf("\nEnter PWM Period (0 - 65535): ");
        scanf("%u", &pwm_period);  // Read user input
        if (pwm_period > 65535) {
            printf("Invalid PWM period! Must be <= 65535.\n\r");
            continue;
        }

        printf("Enter PWM Frequency (Hz): ");
        scanf("%u", &pwm_frequency);  // Read user input

        printf("Enter MUX Select (0 - 7): ");
        scanf("%u", &mux_select);
        if (mux_select > 7) {
            printf("Invalid MUX select! Must be 0-7.\n\r");
            continue;
        }

        // Apply settings
        Xil_Out32(motor_baseaddr + 0x00, pwm_period);      // Set PWM period
        Xil_Out32(motor_baseaddr + 0x04, pwm_frequency);    // Set PWM frequency
        Xil_Out32(motor_baseaddr + 0x08, mux_select);       // Set MUX select

        // Confirm by reading back
        uint32_t read_period = Xil_In32(motor_baseaddr + 0x00);
        uint32_t read_freq = Xil_In32(motor_baseaddr + 0x04);
        uint32_t read_mux = Xil_In32(motor_baseaddr + 0x08);

        uint32_t read_speed = Xil_In32(speedsens_baseaddr + 0x00);

        printf("\nSettings Updated!\n\r");
        printf("Motor period value: 0x%08X\n\r", read_period);
        printf("Motor frequency value: 0x%08X\n\r", read_freq);
        printf("Motor mux value: 0x%08X\n\r", read_mux);

        printf("Motor speed value: %u\n\r", read_speed);

        printf("\n---\n");
    }

    cleanup_platform();
    return 0;
}
