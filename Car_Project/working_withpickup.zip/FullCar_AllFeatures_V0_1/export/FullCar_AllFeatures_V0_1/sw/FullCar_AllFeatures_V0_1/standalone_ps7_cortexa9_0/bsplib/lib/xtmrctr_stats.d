../../../lib/xtmrctr_stats.o: xtmrctr_stats.c xtmrctr.h \
 ../../../include/xil_types.h ../../../include/bspconfig.h \
 ../../../include/xparameters.h ../../../include/xparameters_ps.h \
 ../../../include/xil_assert.h ../../../include/xil_types.h \
 ../../../include/xstatus.h ../../../include/xil_assert.h xtmrctr_l.h \
 ../../../include/xil_io.h ../../../include/xil_printf.h \
 ../../../include/xstatus.h ../../../include/xpseudo_asm.h \
 ../../../include/xreg_cortexa9.h ../../../include/xpseudo_asm_gcc.h
xtmrctr.h:
../../../include/xil_types.h:
../../../include/bspconfig.h:
../../../include/xparameters.h:
../../../include/xparameters_ps.h:
../../../include/xil_assert.h:
../../../include/xil_types.h:
../../../include/xstatus.h:
../../../include/xil_assert.h:
xtmrctr_l.h:
../../../include/xil_io.h:
../../../include/xil_printf.h:
../../../include/xstatus.h:
../../../include/xpseudo_asm.h:
../../../include/xreg_cortexa9.h:
../../../include/xpseudo_asm_gcc.h:
