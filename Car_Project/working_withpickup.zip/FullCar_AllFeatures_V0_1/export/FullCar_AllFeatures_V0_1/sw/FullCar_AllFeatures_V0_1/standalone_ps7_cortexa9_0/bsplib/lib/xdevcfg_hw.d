../../../lib/xdevcfg_hw.o: xdevcfg_hw.c xdevcfg_hw.h \
 ../../../include/xil_types.h ../../../include/bspconfig.h \
 ../../../include/xparameters.h ../../../include/xparameters_ps.h \
 ../../../include/xil_io.h ../../../include/xil_types.h \
 ../../../include/xil_printf.h ../../../include/xstatus.h \
 ../../../include/xil_assert.h ../../../include/xpseudo_asm.h \
 ../../../include/xreg_cortexa9.h ../../../include/xpseudo_asm_gcc.h
xdevcfg_hw.h:
../../../include/xil_types.h:
../../../include/bspconfig.h:
../../../include/xparameters.h:
../../../include/xparameters_ps.h:
../../../include/xil_io.h:
../../../include/xil_types.h:
../../../include/xil_printf.h:
../../../include/xstatus.h:
../../../include/xil_assert.h:
../../../include/xpseudo_asm.h:
../../../include/xreg_cortexa9.h:
../../../include/xpseudo_asm_gcc.h:
