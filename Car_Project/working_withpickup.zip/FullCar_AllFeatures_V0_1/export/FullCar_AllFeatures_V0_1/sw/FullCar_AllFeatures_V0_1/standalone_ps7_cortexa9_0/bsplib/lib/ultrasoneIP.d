../../../lib/ultrasoneIP.o: ultrasoneIP.c ultrasoneIP.h \
 ../../../include/xil_types.h ../../../include/bspconfig.h \
 ../../../include/xparameters.h ../../../include/xparameters_ps.h \
 ../../../include/xstatus.h ../../../include/xil_types.h \
 ../../../include/xil_assert.h
ultrasoneIP.h:
../../../include/xil_types.h:
../../../include/bspconfig.h:
../../../include/xparameters.h:
../../../include/xparameters_ps.h:
../../../include/xstatus.h:
../../../include/xil_types.h:
../../../include/xil_assert.h:
