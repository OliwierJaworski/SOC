src/helloworld.o src/helloworld.o: ../src/helloworld.c ../src/platform.h \
 ../src/platform_config.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h
../src/platform.h:
../src/platform_config.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
