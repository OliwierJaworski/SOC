src/source/manager.o src/source/manager.o: ../src/source/manager.cpp \
 M:\projects\clones\SOC\Car_Project\vitis\SOC_CAR_app\src\include/manager.h \
 M:\projects\clones\SOC\Car_Project\vitis\SOC_CAR_app\src\include/peripheral.h \
 m:\projects\clones\soc\car_project\vitis\soc_car_app\src\platform.h \
 m:\projects\clones\soc\car_project\vitis\soc_car_app\src\platform_config.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xgpio.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_assert.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xstatus.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xgpio_l.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/sleep.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr_l.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xinterrupt_wrap.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xscugic.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xscugic_hw.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_exception.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xdebug.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_spinlock.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xiic_i.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xiic.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xiic_l.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/SpeedSensor_Driver_IP.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/ultrasoneIP.h \
 M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/Motor_DriverIP.h
M:\projects\clones\SOC\Car_Project\vitis\SOC_CAR_app\src\include/manager.h:
M:\projects\clones\SOC\Car_Project\vitis\SOC_CAR_app\src\include/peripheral.h:
m:\projects\clones\soc\car_project\vitis\soc_car_app\src\platform.h:
m:\projects\clones\soc\car_project\vitis\soc_car_app\src\platform_config.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xgpio.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_assert.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xstatus.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xgpio_l.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/sleep.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr_l.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xinterrupt_wrap.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xscugic.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xscugic_hw.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_exception.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xdebug.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xil_spinlock.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xiic_i.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xiic.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/xiic_l.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/SpeedSensor_Driver_IP.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/ultrasoneIP.h:
M:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include/Motor_DriverIP.h:
