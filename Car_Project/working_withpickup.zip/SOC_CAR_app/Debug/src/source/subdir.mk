################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../src/source/manager.cpp \
../src/source/peripheral.cpp 

OBJS += \
./src/source/manager.o \
./src/source/peripheral.o 

CPP_DEPS += \
./src/source/manager.d \
./src/source/peripheral.d 


# Each subdirectory must supply rules for building sources it contributes
src/source/%.o: ../src/source/%.cpp
	@echo 'Building file: $<'
	@echo 'Invoking: ARM v7 g++ compiler'
	arm-none-eabi-g++ -Wall -O0 -g3 -IM:/projects/clones/SOC/Car_Project/vitis/FullCar_AllFeatures_V0_1/export/FullCar_AllFeatures_V0_1/sw/FullCar_AllFeatures_V0_1/standalone_ps7_cortexa9_0/bspinclude/include -I"M:\projects\clones\SOC\Car_Project\vitis\SOC_CAR_app\src\include" -I"M:\projects\clones\SOC\Car_Project\vitis\SOC_CAR_app\src\source" -c -fmessage-length=0 -MT"$@" -mcpu=cortex-a9 -mfpu=vfpv3 -mfloat-abi=hard -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


