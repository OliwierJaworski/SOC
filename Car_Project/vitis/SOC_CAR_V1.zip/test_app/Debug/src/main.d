src/main.o src/main.o: ../src/main.c ../src/pwm_process.h \
 ../src/platform.h ../src/platform_config.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xstatus.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_assert.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr_l.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/Motor_DriverIP.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/SpeedSensor_Driver_IP.h
../src/pwm_process.h:
../src/platform.h:
../src/platform_config.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xstatus.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_assert.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xtmrctr_l.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/Motor_DriverIP.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/SpeedSensor_Driver_IP.h:
