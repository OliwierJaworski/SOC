src/platform.o src/platform.o: ../src/platform.c \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_cache.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 ../src/platform_config.h
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_cache.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
C:/vitis_projects/motor_speedsensor/Motor_and_speed_driver/export/Motor_and_speed_driver/sw/Motor_and_speed_driver/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
../src/platform_config.h:
