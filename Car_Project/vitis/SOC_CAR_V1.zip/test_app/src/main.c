#include "pwm_process.h"
#include "Motor_DriverIP.h"
#include "SpeedSensor_Driver_IP.h"
int main()
{
	int Status;
    init_platform();
    Status = pwmsetup();

    unsigned int motordata=0;

    MOTOR_DRIVERIP_mWriteReg(	XPAR_MOTOR_DRIVERIP_0_S00_AXI_BASEADDR,
    							MOTOR_DRIVERIP_S00_AXI_SLV_REG0_OFFSET,
								5);
    motordata = MOTOR_DRIVERIP_mReadReg(XPAR_MOTOR_DRIVERIP_0_S00_AXI_BASEADDR,MOTOR_DRIVERIP_S00_AXI_SLV_REG0_OFFSET);
    printf("motordata :%u\n\r", motordata);
	/*
    for(;;){
    	unsigned int speedata=0;

    	speedata = SPEEDSENSOR_DRIVER_IP_mReadReg(XPAR_SPEEDSENSOR_DRIVER_IP_0_S00_AXI_BASEADDR, SPEEDSENSOR_DRIVER_IP_S00_AXI_SLV_REG0_OFFSET);
    	printf("speedata :%u\n\r", speedata);
    	usleep(200000);
    }
    */
    cleanup_platform();

    return 0;
}


